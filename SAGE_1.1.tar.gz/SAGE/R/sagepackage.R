#' @name SAGE Exposure
#' @title Exposure
#' @param loc takes the location of the file. make sure the / is a forward slash not the other kind (which R hates).
#' @param e1 takes the name of the txt you pulled from dm. make sure it is saved as tab delimited text file not csv or xls.
#' @param outputtype "p" will save a heat map, while outputtype "d" will output a csv with all of the overlap numbers and percents
#' @export
sage.e<- function(loc, e1, outputType="p"){
  
  library(gplots)
  
  # my test values please ignore
  #loc<-"C:/Users/jwarren/Documents/Client Work - AAC/Workbook clean up/heatmap work"
  #e1<-"overlap17.txt"
  #outputType<-"p"
  
  exloc<-as.character(paste(loc, e1, sep="/"));
  
  Exposure1<-as.data.frame(read.table(exloc, sep="\t", quote="\"", header=TRUE, strip.white=TRUE, fill=TRUE));
  
  
  #define our overlap function
  overlaper<-function(df,a,b){
    if(missing(b)){
      return(sum(df[,1]*df[,a])) 
    }else{
      return(sum(df[,1]*df[,a]*df[,b])) 
    }
  }
  
  # test overlaper overlaper(Exposure1,2,4)
  #get the number of pixel
  ewidth<-dim(Exposure1)[2]
  
  #Clean and store the pixel names
  ename<-gsub("  ", " ", gsub("_", " ", gsub("_uu", "", names(Exposure1[2:ewidth]))))
  
  
  # create a totals matrix to make calculating the overlap % easy
  totals<-matrix(NA, nrow = ewidth-1, ncol = 1)
  for (i in 2:ewidth){
    totals[i-1]<-(overlaper(Exposure1,i))
  }
  
  # create the two matrixes for output
  ematrix <- matrix(NA, nrow = ewidth-1, ncol = ewidth-1)
  ematrixP <- matrix(NA, nrow = ewidth-1, ncol = ewidth-1)
  ematrixMerge <- matrix(NA, nrow = ewidth-1, ncol = ewidth-1)
  cell_values<-matrix("ABC", nrow=ewidth-1, ncol=ewidth-1)
  
  
  # for loop to build our overlaps
  for (i in 2:ewidth){
    for (j in 2:ewidth){
      # get the overlap users
      ematrix[i-1,j-1]<-overlaper(Exposure1,i,j);
      #create a matrx of %s
      ematrixP[i-1,j-1]<-round(ematrix[i-1,j-1]/totals[j-1],3);
      #  merge those two for a nice compact view
      ematrixMerge[i-1,j-1]<-if(i==j){round(totals[i-1],0)}
      else{ematrixP[i-1,j-1]};
      #define the cell labels to be pretty
      cell_values[i-1,j-1]<- if(i==j){format(ematrixMerge[i-1,j-1],big.mark=",",scientific=FALSE)}
      else{paste(round(ematrixP[i-1,j-1]*100,digits=1),"%",sep="")};
      
    }
  }
  
  
  
  
  #apply our cleaned up pixel names to the overlap matrixes
  colnames(ematrix)<-ename
  rownames(ematrix)<-ename
  
  colnames(ematrixP)<-ename
  rownames(ematrixP)<-ename
  
  colnames(ematrixMerge)<-ename
  rownames(ematrixMerge)<-ename
  
  
  # do you want to output to a PNG or the data to csv
  if(tolower(outputType)=="p"){
    pngname<-as.character(paste(e1, "Exposure percent.png", sep="_"));
    outputPNG<-as.character(paste(loc, pngname, sep="/"));
    
    #define our colors with Amnet's palette
    my_palette <- colorRampPalette(c("#cccccc","#00cccc", "#006699","#006699","#006699", "#F15924"))(n = 100)
    
    col_breaks<- c(seq(0,0.3,length=33), # for light grey
                   seq(0.31,0.7,length=33), # for light blue
                   seq(0.71,1,length=11), # for darkblue
                   seq(1.1,1.4,length=11), # for extra room for blue to keep it distant from orange
                   seq(1.5,1.7,length=12), # for extra room for blue to keep it distant from orange
                   seq(1.8,9999999999999,length=1) ) # to color the large number value orange 
   
    #correct the size of the text relative to the output
    cellsizes<-c(5,5,5,5,4,3.7,3.7,3.2,3,3,2.7,2.5,2.4,2.2,2,2,1.7,1.7,1.7,1.7,1.7)
    Csize<-cellsizes[ewidth-1]
    
    labelsizes<-c(4,4,4,4,4,3.7,3.7,3.2,3,3,2.7,2.5,2.4,2.2,2,2,2,2,2,2,2)
    Lsize<-labelsizes[ewidth-1]
    
    Cellcol<- if(ewidth>14){"Black"}else{"White"}
     
    
    png(filename=outputPNG, width = 3000, height = 1700, units = "px",)
    heatmap.2(ematrixMerge,
              cellnote = cell_values,   # same data set for cell labels
              notecex=Csize,cexCol =Lsize,cexRow=Lsize,  # increase the size of text
              main = as.character(paste("Exposure Report ", e1, sep="")),     # heat map title
              notecol=Cellcol,      # change font color of cell labels to black
              density.info="none",  # turns off density plot inside color legend
              trace="none",         # turns off trace lines inside the heat map
              margins =c(17,50),    # widens margins around plot so labels don't get cut off
              col=my_palette,       # use on color palette defined earlier 
              breaks=col_breaks,    # enable color transition at specified limits
              colsep=c(1:ewidth),
              rowsep=c(1:ewidth),
              dendrogram="none", # Turns off dentrograms
              key=FALSE,
              Rowv=FALSE, 
              symm = TRUE,
              srtCol=30,
              Colv=FALSE)  # stops column sorting
    dev.off()
        
    
    
  }else if (tolower(outputType)=="d"){
    
    # create spacers
    blanks <- matrix("  ",nrow=2, ncol = ewidth-1)
    
    #join all of the matrices into one for export
    ematrixExport<-rbind(ematrix,blanks,ematrixP,blanks,ematrixMerge)
    
    #name the columns and rows
    colnames(ematrixExport)<-ename
    rownames(ematrixExport)<-c(ename,"","",ename,"","",ename)
    
    # outputs to csv files
    outputloc<-as.character(paste(loc, "Exposure data.csv", sep="/"));
    write.table(ematrixExport, file = outputloc, append = FALSE, quote = FALSE, sep = ",",
                eol = "\n", na = "NA", dec = ".", row.names = TRUE,
                col.names = TRUE, qmethod = c("escape", "double"));
    
    
  }
  
  
  
};

#' @name SAGE Site Insight
#' @title Site Insight
#' @param loc Takes the location of the files. make sure the / is a forward slash not the other kind (which R hates).
#' @param m1 This is the name of the first file in the zip. It will always be much larger and contain TLDs
#' @param m2 is the second file. It will only have 2 rows, titles and sums
#' @param TLDcategories is an optional file that has an IAB category for every TLD. For Those in the USA set this parameter to "USA" and R will grab the files from the M drive. Those outside the US can add their full filename and location or omit the parameter 
#' @param TLDcomScore is an optional file that has an comscore rank for every TLD. For Those in the USA set this parameter to "USA" and R will grab the files from the M drive. Those outside the US can add their full filename and location or omit the parameter
#' @export
sage.s <-
  function(loc, m1, m2,TLDcategories=NULL,TLDcomScore=NULL ){
    
    
    ### SITE INSIGHT workbook####
    library(reshape2)
    
    # test values please ignore
    #loc<-'C:/Users/jwarren/Documents/Client Work - AAC/Workbook clean up'
    #m1<-'Discover-SI-2015_46367618.mqo1.txt'
    #m2<-'Discover-SI-2015_46367618.mqo2.txt'
    
    siteloc<-as.character(paste(loc, m1, sep="/"))
    totalsloc<-as.character(paste(loc, m2, sep="/"))
    
    
    # load site data
    site1<-as.data.frame(read.table(siteloc, sep="\t", quote="\"", header=TRUE, strip.white=TRUE, fill=TRUE));
    #load user totals
    totals<-as.data.frame(read.table(totalsloc, sep="\t", quote="\"", header=TRUE, strip.white=TRUE, fill=TRUE));
    names(totals)<-as.character(paste(names(totals), "_Totals", sep=""))
    
    #get the sizes of our workspace
    sitelen<-dim(site1)[1]
    stewidth<-dim(site1)[2]
    #start the index matrix and calculate all of the site indexes
    Index<-as.data.frame(NULL)
    for  (i in 1:sitelen){
      for (j in 4:stewidth){
        Index[i,(j-3)]<-(site1[i,j]/totals[1,(j-1)])/(site1[i,3]/totals[1,2])
        
      }
    }    
    
    #name the index matrix  pixelname + "_index"
    names(Index)<-as.character(paste(names(site1[4:stewidth]), "_Index", sep=""))
    
    site2<-cbind(site1,Index)
    
    
    # add optional IAB and Comscore categorizations 
    if(is.null(TLDcategories))  {
           # the case with omited parameter
            site3<-site2 
      
    } else if(tolower(TLDcategories)=="usa") {
      #the US case
      cats<-read.csv(file="M:/AMNET GROUP/Analytics/DataSources/TLD/r/tld Cat.csv",header=TRUE,sep=",") 
      site3<-merge(site2, cats, by.site2="tld" , by.cats="tld", all.x= TRUE)
      
    } else {
      #the case where a filename and location is given
      cats<-read.csv(file=TLDcategories,header=TRUE,sep=",") 
      site3<-merge(site2, cats, by.site2="tld" , by.cats="tld", all.x= TRUE)
      
    }
    # add optional Comscore categorizations
    if(is.null(TLDcomScore)) {
      # the case with omited parameter
      site4<-site3
      
    } else if(tolower(TLDcomScore)=="usa")  {

      #the US case
      comscore<-read.csv(file="M:/AMNET GROUP/Analytics/DataSources/TLD/r/comscore.csv",header=TRUE,sep=",") 
      site4<-merge(site3, comscore, by.site3="tld" , by.comscore="tld", all.x= TRUE)
      
    } else {
      #the case where a filename and location is given
      cats<-read.csv(file=TLDcomScore,header=TRUE,sep=",") 
      site4<-merge(site3, comscore, by.site3="tld" , by.comscore="tld", all.x= TRUE)
      
    }
    
    
    outputloc<-as.character(paste(loc, "Site_output.csv", sep="/"));
    
    write.table(site4, file = outputloc, append = FALSE, quote = FALSE, sep = ",",
                eol = "\n", na = "NA", dec = ".", row.names = FALSE,
                col.names = TRUE, qmethod = c("escape", "double"));
    
  };

#' @name SAGE Geo Insight
#' @title Geo Insight
#' @param loc takes the location of the file. make sure the / is a forward slash not the other kind (which R hates).
#' @param g1 takes the name of the txt you pulled from dm. make sure it is saved as tab delimited text file not csv or xls.
#' @param US=TRUE is you are in the US you can ignore this argument. If you are in EMEA or elsewhere make sure to set it to false :)
#' @param GEOTYPE will let you select which type of granularity you want in the index. It accepts "state" or "dma" otherwise it will produce index results for each combination or region and city 
#' @param outputmap if you want a map as the output set this to TRUE if you want an excel output set this to FALSE
#' @export
sage.g <-
  function(loc, g1, US=TRUE, GEOTYPE=NULL, outputmap=FALSE){
    
    
    
    #' this does the US state mapping for SAGE.GI. I wouldnt suggest you call it directly
    #' @param xx takes the output from SAGE.GI with index values for each US state.
       #' @param loc takes the same location from SAGE.GI to store the output map.
       #' @return Maps for each pixel saved in the loc folder.
       #' @export
       mapstate<-function(xx, loc){
         library(maps)
         library(mapproj)
         
         #pull in a state table ## will need to generalize this location
         StateName <- read.csv("M:/AMNET GROUP/Analytics/DataSources/Geo/statepop.csv")
         
         # merge geo data and stateName into one big table and make the long names lowercase
         GeoIndexBig<-merge(StateName,xx,by.x="Shortstate",by.y="region_name")
         GeoIndexBig$Longstate<-tolower(GeoIndexBig$Longstate)
         
         ##make map names lower case and remove non-states
         mapnames<- map("state", plot=FALSE)$names
         mapnames.state<- ifelse(regexpr(":",mapnames) < 0, mapnames, substr(mapnames, 1, regexpr(":",mapnames)-1))
         
         ###get the location for the first index and the end
         length<-dim(GeoIndexBig)[2]
         indexlocation<-length-(length-grep("cat_uu",names(GeoIndexBig)))/2+1
         
         
         eachMap.state<-function(zz){
           
           #define a function that takes an array and outputs a map
           GeoColorID <- apply(zz,1, function(ff) as.numeric(cut(ff, c(-.5,-.3,-.1,.1,.3,.5,1,1.5,2))))
           
           my.palette <- c("#f7fbff","#deebf7","#c6dbef","#9ecae1","#6baed6","#4292c6","#2171b5","#08519c","#F15924")
           GeoCol<-my.palette[GeoColorID]
           GeoCol[is.na(GeoCol)]<-"#FFFFFF"
           
           ############create a map##########
           titletext<-as.character(paste(names(zz), "png", sep="."))
           outputPNG<-as.character(paste(loc, titletext, sep="/"));
           
           
           png(filename=outputPNG, width = 1000, height = 700, units = "px",)
           
           # Create two panels side by side
           layout(t(1:3), widths=c(1000,75,50))
           par(las=1,cex.main=2, cex.axis=2)
           
           #plot the map and add a tittle
           map("state",fill=TRUE,col=GeoCol  ,proj="albers",param=c(35,50))
           title(titletext)
           
           # Draw the color legend
           legend("bottomleft", fill = my.palette, legend = c(-.5,-.3,-.1,.1,.3,.5,1,1.5,2), col = my.palette,cex = 2)
           
           dev.off()  
         }
         
         
         #itterate through the columns
         for (i in indexlocation:length)
         {#state
           eachMap.state(GeoIndexBig[i]) 
         }
         
       }
       
       #' this does the US DMA mapping for SAGE.GI. I wouldnt suggest you call it directly
       #' @param xx takes the output from SAGE.GI with index values for each US DMA
       #' @param loc takes the same location from SAGE.GI to store the output map.
       #' @return Maps for each pixel saved in the loc folder.
       #' @export
       mapdma<- function(xx,loc){
         
         library(maptools)
         library(rgdal)
         library(ggplot2)
         library(plyr)
         
         ##load the ordered DMA Names
         dmanames<-read.csv("M:/AMNET GROUP/Analytics/SAGE 2.0/R/dmanames.csv")
         mergeDMA<-merge(dmanames,xx, by.x="dmamatch", by.y="dma_name",all.dmanames = TRUE )
         
         ###get the location for the first index and the end
         length<-dim(mergeDMA)[2]
         indexlocation<-length-(length-grep("cat_uu",names(mergeDMA)))/2+1
         
         
         eachMap.dma<-function(zz){
           fn<-'M:/AMNET GROUP/Analytics/SAGE 2.0/R/nielsendma.kml'
           kml <- readOGR(fn, layer="Nielsen DMAs (U.S. Media markets)")
           
           # Validating the DMA name order so we can apply their names to match
           # kml$Description[1][55:75]
           # dff<-NULL
           # for (i in 1:206){
           #   dff[i]<-as.character(kml$Description[i])
           #   foo[i] <- data.frame(do.call('rbind', strsplit(as.character(dff[i]),'<b>',fixed=TRUE)))[8]
           #   foo<-t(foo)
           # }
           #test that matched names are ordered the same as KML
           # dmanames$dmlxml[200]
           # foo[200]
           kml$Name<-dmanames$dmamatch
           
           GeoColorID <- apply(zz,1, function(ff) as.numeric(cut(ff, c(-.5,-.3,-.1,.1,.3,.5,1,1.5,2))))
           
           my.palette <- c("#f7fbff","#deebf7","#c6dbef","#9ecae1","#6baed6","#4292c6","#2171b5","#08519c","#F15924")
           
           
           titletext<-as.character(paste(names(zz), "png", sep="."))
           outputPNG<-as.character(paste(loc, titletext, sep="/"));
           
           
           ############create a map##########
           png(filename=outputPNG, width = 1000, height = 700, units = "px",)
           #plot the map and add a tittle
           plot(kml ,col=my.palette[GeoColorID])
           title(titletext)
           legend("bottomleft", fill = my.palette, legend = c(-.5,-.3,-.1,.1,.3,.5,1,1.5,2), col = my.palette)
           dev.off() 
         }
         
         #itterate through the columns
         for (i in indexlocation:length)
         {
           eachMap.dma(mergeDMA[i]) 
         }
         
         
         
       }
       
       
       
       ### GEO INSIGHT workbook####
       library(reshape2)
       
       
       # test locations
       # loc<-'C:/Users/jwarren/Documents/Client Work - AAC/Workbook clean up/map work'
       # g1<-'dmaTestData.txt'
       
       geoLoc<-as.character(paste(loc, g1, sep="/"))
       
       
       # load site data
       Geo1<-as.data.frame(read.table(geoLoc, sep="\t", quote="\"", header=TRUE, strip.white=TRUE, fill=TRUE));
       
       #   filter for just US
       if(US){Geo2<-Geo1[Geo1[, "country_name"]=="United States", ]}
       else{Geo2<-Geo1}
       
       
       geowidth<-dim(Geo2)[2]
       
       gnames<-names(Geo2)
       
       #find the cat uu position to break out variables vs measures
       catlocation<-grep("cat_uu",gnames)
       
       
       geoValues<-gnames[catlocation:geowidth]
       
       # index on city ,state or DMA
       if(tolower(GEOTYPE)=="state") {
         #melt for state
         geoMelt <- melt(Geo2, id=c("country_name","region_name"), measure=gnames[catlocation:geowidth]) 
         geoCast<-dcast(geoMelt, region_name  ~ variable  , fun.aggregate=sum)
         totals<-colSums(Filter(is.numeric, geoCast))
         
       } else if(tolower(GEOTYPE)=="dma")  {
         Geo2$dma_name<-as.character(paste(Geo2$dma_name,Geo2$dma_id, sep=""))
         geoMelt <- melt(Geo2, id=c("country_name","dma_name"), measure=gnames[catlocation:geowidth]) 
         geoCast<-dcast(geoMelt, dma_name ~ variable  , fun.aggregate=sum)
         totals<-colSums(Filter(is.numeric, geoCast))
         
       } else {
         geoCast<-dcast(geoMelt,region_name + city_name ~ variable  , fun.aggregate=sum)
         totals<-colSums(Filter(is.numeric, geoCast[,-2]))
       }
       
       #get object sizes to have them handy
       totalwidth<-length(totals)
       castlen<-dim(geoCast)[1]
       castwidth<-dim(geoCast)[2]
       
       
       catlocation<-grep("cat_uu",names(geoCast))
       
       Index<-as.data.frame(NULL)
       
       for  (i in 1:castlen){
         for (j in 1:(totalwidth-1)){
           
           Index[i,j]<-(geoCast[i,j+catlocation]/totals[j+1])/(geoCast[i,catlocation]/totals[1])
           if(is.null(Index[i,j])) {Index[i,j]<-0}
         }
       }    
       
       names(Index)<-as.character(paste(names(totals[2:totalwidth]), "_Index", sep=""))
       
       
       Geooutput<-cbind(geoCast,Index)
       outputloc<-as.character(paste(loc, "geo_output.csv", sep="/"));
       
       write.table(Geooutput, file = outputloc, append = FALSE, quote = FALSE, sep = ",",
                   eol = "\n", na = "NA", dec = ".", row.names = FALSE,
                   col.names = TRUE, qmethod = c("escape", "double"));
       
       
       if(outputmap){if(tolower(GEOTYPE)=="state") {
         mapstate(Geooutput,loc)
       } else if(tolower(GEOTYPE)=="dma")  {
         mapdma(Geooutput,loc) 
       } else {
         mapcity(Geooutput,loc)
       }  
       
       }
  };


#' @name SAGE Audience Insight
#' @title Audience Insight
#' @param loc takes the location of the file. make sure the / is a forward slash not the other kind (which R hates).
#' @param a1 takes the name of the txt you pulled from dm. make sure it is saved as tab delimited text file not csv or xls.
#' @param taxFile takes the filename and location of our audience taxonomy document. If left out it defaults to the file on the US shared drive.
#' @export
sage.a<- 
  function(loc, a1, taxFile=NULL){
  
    # ---------------------------------------------------------------------------------------------------------
    # Audience Insights R Template 4.8
    # ---------------------------------------------------------------------------------------------------------
    rm(list=ls()); cat('\014'); require(reshape2); 
    
    
    
    # Yohaan WRITTEN FUNCTIONS 
    
    # column.names() is a function I wrote to create a table that shows 3 things: the name of the columns of 
    # an object, the number of the columns' order, and the class the values in each column are. 
    # Example: View(column.names(data)) 
    
    column.names<-function(x)
    {
      temp<-as.data.frame(get(paste('x'))); 
      cols<-as.data.frame(matrix("", nrow=length(temp), ncol=3)); 
      colnames(cols)<-c("no", "name", "class"); 
      for ( c in 1:length(cols) ) { cols[,c]<-as.character(cols[,c])}; rm(c)
      cols$no<-as.numeric(1:length(temp))
      for ( c in 1:length(temp) )
      {
        cols$name[c]<-as.character(colnames(temp)[cols$no[c]])[1]
        cols$class[c]<-as.character(class(temp[,cols$no[c]]))[1]
      }; rm(c); 
      return(cols); 
    }
    
    # column.convert() is a function I wrote in my "columns.r" file (also shown at the end of this script). 
    # The column.convert() function takes a data.frame object and converts the class of each column to characters 
    # and deletes any lingering spaces before or after any value in all columns. 
    # In addition, it also changes any periods in the column names to underscores and makes all cases lower-cased 
    # in the column names.
    
    column.convert<-function(x) 
    {
      temp<-as.data.frame(get(paste('x'))); 
      print("Convert & Trim to Character")
      for ( t in 1:length(temp) ) 
      {
        temp[,t]<-as.character(temp[,t]); 
        temp[,t]<-as.character(gsub("^ ", "", temp[,t])); 
        temp[,t]<-as.character(gsub(" $", "", temp[,t])); 
      }; rm(t); 
      print("Column Format") 
      colnames(temp)<-as.character(tolower(colnames(temp))); 
      colnames(temp)<-as.character(gsub("\\.", "_", colnames(temp))); 
      colnames(temp)<-gsub("_$", "", colnames(temp)); 
      return(temp)
    }
    # ---------------------------------------------------------------------------------------------------------
    # LOADING THE DATA ----------------------------------------------------------------------------------------
    
    # Personally, I like to load the file into an object called "raw" and then create a duplicate object called 
    # "data" so that I can retrace my steps from the original file. That's essentially what takes place here. 
    
    
    # Currents File
    if(is.null(taxFile)){
      currents<-read.csv(file="M:/AMNET GROUP/Analytics/DataSources/Audience Insight/Crrentcategories7272015.csv",header=TRUE,sep=",") 
    }else if(tolower(taxFile)=="usa"){
      currents<-read.csv(file="M:/AMNET GROUP/Analytics/DataSources/Audience Insight/Crrentcategories7272015.csv",header=TRUE,sep=",") 
      ###load('/users/ylee/Documents/r source code/data template/currents.rdata'); 
    } else {
      currents<-read.csv(file=taxFile,header=TRUE,sep=",") 
    }
    
    
    ailoc<-as.character(paste(loc, a1, sep="/"));
    raw1<-as.data.frame(read.table(ailoc, sep="\t", quote="\"", header=TRUE, strip.white=TRUE, fill=TRUE));
    
    ## Yohaan's data loadraw1<-as.data.frame(read.table('/Users/ylee/documents/R source code/data template/R input/audience/raw data.txt', sep="\t", quote="\"", header=TRUE, strip.white=TRUE, fill=TRUE));
    
    # FORMAT DATA FOR MERGER WITH CURRENTS DATA. --------------------------------------------------------------
    
    data<-column.convert(raw1)
    
    # column.convert() converts all columns in the specified data frame (in this case, "raw1") and trims the 
    # values so that there are no spaces before or after the values in the columns. 
    
    # ---------------------------------------------------------------------------------------------------------
    # CREATING THE "taxonomy" COLUMN FOR JOINING WITH CURRENTS ------------------------------------------------
    # Since the data file is joined with the currents file by the column "taxonomy" which are string values, 
    # this section also manipulates the "taxonomy" column to be all lower-case and without spaces. 
    # This is because if there are any differences in cases or spacing in the two files' "taxonomy" column, the 
    # joining of the data will be unsuccessful. 
    
    data$taxonomy<-as.character(paste(data$contract_name, data$category_fullpath_name, sep="")); 
    data$taxonomy<-as.character(gsub(" ", "", tolower(data$taxonomy)))
    
    # ---------------------------------------------------------------------------------------------------------
    # FORMATTING THE AUDIENCE DATA IN THE DATA FRAME OBJECT "data" --------------------------------------------
    # This section of the code formats the data frame object "data" (which is the audience data) so that the first 
    # five columns (which are always "data_provider_name", "contract_name", "contract_id", "category_fullpath_
    # name", "category_id" in the query builder) are string values and the remaining columns are numeric values. 
    # Because the "taxonomy" column needs to remain a string value and it was just added onto the "data" object,
    # the code here also makes the final column of the "data" object a string value (line 67 - 70). 
    # ---------------------------------------------------------------------------------------------------------
    
    for ( d in 1:length(data) ) 
    { 
      if ( d<=5 ) 
      {
        data[,d]<-as.character(data[,d]); 
      }else{
        if ( d>=6 & d<length(data) )  
        {
          data[,d]<-as.character(data[,d]); 
          data[,d]<-as.numeric(data[,d]); 
        }else{
          if ( d==length(data) ) 
          {
            data[,d]<-as.character(data[,d]) 
          }
        }
      }
    }; rm(d) 
    
    # ---------------------------------------------------------------------------------------------------------
    # REORGANIZE COLUMNS --------------------------------------------------------------------------------------
    
    # NOTE: When performing a join between 2 data objects, R automatically attempts to join the the two objects 
    # by all columns with the same column name. To be sure that only the "taxonomy" column is used to join, this
    # section of the code deletes the "data_provider_name", "contract_name", "contract_id", "category_fullpath_
    # name", "category_id" columns in the "data" object since it already exists in the "currents" file. 
    
    taxonomy<-as.character(data$taxonomy)
    temp<-as.data.frame(data[,6:(length(data)-1)])
    
    data<-as.data.frame(cbind(taxonomy, temp))
    data$taxonomy<-as.character(data$taxonomy) 
    rm(temp, taxonomy)
    
    # cbind() combines columns and matrices adjacently. 
    # When performing a "cbind" command in R, the resulting data frame will automatically change the class of 
    # non-matrix objects or objects that are not data frames into factors. When the "cbind()" was performed 
    # here, the "taxonomy" column becomes a factor. To account for this, the "taxonomy" column is reverted
    # to string values. 
    
    # Note: when converting a factor into a numeric value directly, R changes the numerical value of the data. 
    # Ex. the values in Set A become the values in Set B when converted from factors to numerics. 
    # Set A: "33", "09", "10", "06", "05", "14", "03", "04", "00", "02" - factors
    # Set B: "10", "07", "08", "06", "05", "09", "03", "04", "01", "02" - numeric
    
    # ---------------------------------------------------------------------------------------------------------
    # JOINING THE DATA WITH CURRENTS BY THE "taxonomy" COLUMN -------------------------------------------------
    # This section manipulates the "taxonomy" column in the "currents" object so that it is also lower case and 
    # without space (just like the taxonomy column in our "data" object) to allow seamless joining. 
    
    currents$taxonomy<-as.character(gsub(" ", "", tolower(currents$taxonomy)))
    data<-as.data.frame(merge(currents, data, by.currents=taxonomy, by.data=taxonomy))
    
    # Once the join is performed, the resulting file is in the object "data". To be sure the class of the column 
    # values arent changed, all of the columns are first converted to strings and the numeric columns are converted 
    # appropriately soon after. 
    
    # NOTE: THIS IS ALSO WHERE YOU CAN MULTIPLY YOUR FIGURES IF YOU SAMPLED YOUR QUERIES. 
    # In turn, we often sample our queries to save query time. To multiply the numbers, You can use this 
    # section of the code. (line 156)
    
    data<-column.convert(data)
    for ( d in 1:length(data) ) 
    {
      if ( d<=9 )
      {
        data[,d]<-as.character(data[,d])
      }else{
        if ( d>=10 ) 
        {
          data[,d]<-as.character(data[,d]); 
          data[,d]<-as.numeric(data[,d]);
          # data[,d]<-as.numeric(data[,d]*X); MULTIPLY BY FACTOR 'X' HERE
        }
      }
    }; rm(d)
    
    # In tableau, the "data_selection" column is used to aggregate values, so to remove any discrepancies, the 
    # spaces before and after the colon in "data_selection" are deleted. (it caused an issue before)
    
    data$data_selection<-gsub(" \\: ", ":", data$data_selection)
    
    # ---------------------------------------------------------------------------------------------------------
    # CALCULATING TOTALS TO PREPARE FOR THE INDEX CALCULATION -------------------------------------------------
    
    # In this section, the code creates a data frame object called "aggs" by performing a "cbind" command on the 
    # factor value "total" and "data". 
    
    # The data frame object "aggs" will provide the figures used in the base index later when calculating the 
    # final index for each data selection's category. The resulting numeric columns (the columns with the user 
    # counts) will be renamed to include the prefix "sum_". (ex. if the column name is "pixel1" then the 
    # resulting column name will be "sum_pixel1"). 
    
    aggs<-as.data.frame(cbind(factor("total"), data)); colnames(aggs)[1]<-"total"
    
    for ( a in 1:10 ) {aggs[,a]<-as.character(aggs[,a]); aggs[,a]<-factor(aggs[,a]); }; rm(a)
    aggs<-as.data.frame(melt(aggs)); 
    aggs<-as.data.frame(dcast(aggs, data_selection ~ variable, sum))
    aggs$data_selection<-as.character(aggs$data_selection)
    
    for ( a in 2:length(aggs) )
    { 
      colnames(aggs)[a]<-as.character(paste('sum_', colnames(aggs)[a], sep=''))
    }; rm(a)
    
    # ---------------------------------------------------------------------------------------------------------
    # FINAL FILE OUTPUT ---------------------------------------------------------------------------------------
    
    # Lastly, here the code merges the totals for each data_selection aggregated in the data frame "aggs" and 
    # joins it to the data frame "data" and outputs a file ready to be used in Tableau. 
    
    data<-as.data.frame(merge(data, aggs, by.data=data_selection, by.aggs=data_selection))
    
    outputloc<-as.character(paste(loc, "audience insights data - tableau ready.txt", sep="/"));
    write.table(data, file=outputloc, sep='\t', row.names=FALSE, quote=FALSE, col.names = TRUE)
    
    
    
  };


#' htmlwidget for d3.js sequence sunburst diagrams
#'
#' \href{https://gist.github.com/kerryrodden/7090426}{Sequences sunburst} diagrams provide
#'    an interactive method of exploring sequence data, such as website navigation paths.
#'
#' @param csvdata data in csv source,target form
#' @param jsondata data in nested d3 JSON hierarchy with `{name:...,  children:[];}`
#' @param legendOrder string vector if you would like to manually order the legend.
#'          If legendOrder is not provided, then the legend will be in the descending
#'          order of the top level hierarchy.
#' @param colors \code{vector} of strings representing colors as hexadecimal for
#'          manual colors.
#' @param percent \code{logical} to include percentage of total in the explanation.
#' @param count \code{logical} to include count and total in the explanation.
#' @param explanation JavaScript function to define a custom explanation for the center
#'          of the sunburst.  Note, this will override \code{percent} and \code{count}.
#' @param breadcrumb,legend \code{list} to customize the breadcrumb trail or legend.  This argument
#'          should be in the form \code{list(w =, h =, s =, t = )} where
#'          \code{w} is the width, \code{h} is the height, \code{s} is the spacing,
#'          and \code{t} is the tail all in \code{px}.
#' @param sortFunction \code{\link[htmlwidgets]{JS}} function to sort the slices.
#'          The default sort is by size.
#'
#' @example inst/examples/example_replicate.R
#' @example inst/examples/example_ngram.R
#'
#' @import htmlwidgets
#'
#' @export
sunburst <- function(
  csvdata = NULL
  , jsondata = NULL
  , legendOrder = NULL
  , colors = NULL
  , percent = TRUE
  , count =  FALSE
  , explanation = NULL
  , breadcrumb = list()
  , legend = list()
  , sortFunction = NULL
  , width = NULL
  , height = NULL
) {
  
  if(is.null(csvdata) && is.null(jsondata)) stop("please provide either csvdata or jsondata",call.=FALSE)
  if(!is.null(csvdata) && !is.null(jsondata)) warning("both csv and json provided; will use csvdata",call.=FALSE)
  
  if(!is.null(explanation) && !inherits(explanation,"JS_EVAL")){
    explanation = htmlwidgets::JS(explanation)
  }
  
  # forward options using x
  x = list(
    csvdata = csvdata
   ,jsondata = jsondata
    ,options = list(
      legendOrder = legendOrder
      ,colors = colors
      ,percent = percent
      ,count = count
      ,explanation = explanation
      ,breadcrumb = breadcrumb
      ,legend = legend
      ,sortFunction = sortFunction
    )
  )
  
  # create widget
  htmlwidgets::createWidget(
    name = 'sunburst',
    x,
    width = width,
    height = height,
    package = 'sunburstR'
  )
}

#' Widget output function for use in Shiny
#'
#' @export
sunburstOutput <- function(outputId, width = '100%', height = '400px'){
  shinyWidgetOutput(outputId, 'sunburst', width, height, package = 'sunburstR')
}

#' Widget render function for use in Shiny
#'
#' @export
renderSunburst <- function(expr, env = parent.frame(), quoted = FALSE) {
  if (!quoted) { expr <- substitute(expr) } # force quoted
  shinyRenderWidget(expr, sunburstOutput, env, quoted = TRUE)
}



#' custom html function for sunburst
#' @import htmltools
sunburst_html <- function(id, style, class, ...){
  tagList(
    tags$div( id = id, class = class, style = style, style="position:relative;"
              ,tags$div(
                tags$div(class = "sunburst-main"
                         , tags$div( class = "sunburst-sequence" )
                         , tags$div( class = "sunburst-chart"
                                     ,tags$div( class = "sunburst-explanation", style = "visibility:hidden;"
                                                #       ,tags$span( class = "sunburst-percentage")
                                     )
                         )
                )
                ,tags$div(class = "sunburst-sidebar"
                          , tags$input( type = "checkbox", class = "sunburst-togglelegend", "Legend" )
                          , tags$div( class = "sunburst-legend", style = "visibility:hidden;" )
                )
              )
    )
  )
}


